from tkinter import *
import tkinter.messagebox as tmsg
from tkinter import filedialog
from PIL import Image,ImageTk

#-------------------------- Basic Window Code ------------------------------------- 


gui=Tk()
gui.geometry('400x400')
gui.title('Untitled - Notepad')
gui.minsize(300,300)
image=Image.open('icon2.png')
photo=ImageTk.PhotoImage(image)
gui.iconphoto(True,photo)


# ------------------------- Functions Here ---------------------------------------

def savefile():
    global filename
    filedir=filedialog.asksaveasfilename(title='Save As',initialfile=f'{filename}',defaultextension='.txt',filetypes=[('All formats','*.*'),('text documents','*.txt')])
    if filedir:
        statusVar.set('File is saved.')
        statusbar.update()

def openfile():

    filedir=None
    filedir=filedialog.askopenfilename(title='Select file',defaultextension='.txt',filetypes=[('All formats','*.*'),('Text document','.txt'),('C file','.c'),('Java file','.java'),('Python file','.py')])
    if filedir:
        global filename
        filename=filedir
        filer(filedir)
        

def filew(name,txt):
    print(f'{name}............')
    with open(name,'a') as f:
        f.write(f'{txt}')
    gui.title(f'{name} - Notepad')

def filer(name):
    print(f'{name}...')
    with open(name,'r') as f:
        inp.delete(1.0,END)
        cont=f.read()
        inp.insert(1.0,cont)
        statusVar.set('File is opened successfully. Remember to save the file if you have changed it\'s contents.')
        statusbar.update()
        
    gui.title(f'{name} - Notepad')
   
def help():
    txt='''
    -------------------------------------------
    
    Use Shift + Arrow key to select text
    Use Ctrl + X to cut selected text
    Use Ctrl + C to copy selected text
    Use Ctrl + V to paste selected text
    Use Ctrl + Z to undo
    Use Ctrl + Y to redo

    --------------------------------------------
    '''
    tmsg.showinfo('Help box',f'{txt}')

def undo():
    try:
        inp.edit_undo()
    except:
        tmsg.showinfo('Info','Nothing to Undo Here...')

def redo():
    try:
        inp.edit_redo()
    except:
        tmsg.showinfo('Info','Nothing to Redo Here...')

def quitfunc():
    txt=inp.get('1.0','end-1c')
    txt=txt.strip()
    if txt!='':
        if tmsg.askyesnocancel('Warning','Wanna save your file ?'):
            savefile()
            quit()
        else:
            quit()
    else:
        quit()


# -------------------- Main body -------------------------


starttext='''--------------------------------------------------------------------------------
            Welcome to notepad made by Ronak Suthar here you can open and save different 
            kinds of files and also perform normal operations and make sure to keep an eye
            on status bar below while editing the file.'''
filename= None

fr=Frame(gui)
fr.pack(fill=BOTH)

# menu settings

menubtn=Menubutton(fr,text="OPEN",activebackground='lightgray')
menubtn.pack(side=LEFT)
menubtn.bind('<Button-1>',lambda event:openfile())
menubtn=Menubutton(fr,text="SAVE",activebackground='lightgray')
menubtn.pack(side=LEFT)
menubtn.bind('<Button-1>',lambda event:savefile())
menubtn=Menubutton(fr,text="HELP",activebackground='lightgray')
menubtn.pack(side=LEFT)
menubtn.bind('<Button-1>',lambda event:help())
# fr1=Frame(fr)
menubtn=Menubutton(fr,text="REDO",background='lightgray',foreground='black',activebackground='silver')
menubtn.pack(side=RIGHT)
menubtn=Menubutton(fr,text="UNDO",background='lightgray',foreground='black',activebackground='silver')
menubtn.pack(side=RIGHT)
menubtn.bind('<Button-1>',lambda event:undo())
menubtn.bind('<Button-1>',lambda event:redo())
# fr1.pack(side=LEFT,padx=20)

# scroll bar settings

var=StringVar()
sbar=Scrollbar(gui)
sbar.pack(side=RIGHT,fill=Y)
inp = Text(gui,font='lucida 10',yscrollcommand=sbar.set,undo=True)
inp.insert('1.0',starttext)
inp.pack(expand=True,fill=BOTH)
sbar.config(command=inp.yview)

# status bar settings 

statusVar=StringVar()
statusVar.set('start typing above...')
statusbar=Label(textvariable=statusVar,relief=SUNKEN,anchor=W)
statusbar.pack(side=BOTTOM,fill=X)

# dialog box before exiting window

gui.protocol("WM_DELETE_WINDOW", quitfunc)

gui.mainloop()